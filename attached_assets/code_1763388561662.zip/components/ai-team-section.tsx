"use client"

import { useState, useEffect, useRef } from "react"
import { MessageCircle, Clock, Zap } from 'lucide-react'

const conversations = [
  {
    title: "Đặt Lịch Làm Nail & Tư Vấn Dịch Vụ",
    messages: [
      { text: "Xin chào! Em muốn đặt lịch làm nail cho thứ 7 tuần này ạ", sender: "customer", delay: 0 },
      {
        text: "Dạ em chào chị! Chị muốn làm dịch vụ gì ạ? Bên em có dịch vụ Manicure, Pedicure, gel, và nail design.",
        sender: "ai",
        delay: 1000,
      },
      {
        text: "Em muốn làm combo mani-pedi với gel polish màu nude nhẹ nhàng",
        sender: "customer",
        delay: 2500,
      },
      {
        text: "Dạ vâng! Combo mani-pedi với gel polish là $65. Thứ 7 này chị có thể đến lúc 10am, 2pm, hoặc 4pm. Chị chọn giờ nào tiện ạ?",
        sender: "ai",
        delay: 3500,
      },
      { text: "2pm được em nhé!", sender: "customer", delay: 5000 },
      {
        text: "Dạ em đã book lịch cho chị lúc 2pm thứ 7. Chị sẽ nhận được tin nhắn xác nhận ngay ạ. Hẹn gặp chị!",
        sender: "ai",
        delay: 6000,
      },
    ],
  },
  {
    title: "Đặt Bàn Nhà Hàng & Menu",
    messages: [
      { text: "Cho em hỏi nhà hàng có món phở bò không ạ?", sender: "customer", delay: 0 },
      {
        text: "Dạ có ạ! Bên em có phở bò tái, phở bò chín, và phở đặc biệt. Giá từ $12-$15 tùy size ạ.",
        sender: "ai",
        delay: 1000,
      },
      {
        text: "Tuyệt! Em muốn đặt bàn cho 4 người tối nay được không?",
        sender: "customer",
        delay: 2500,
      },
      {
        text: "Dạ được ạ! Chị muốn đặt lúc mấy giờ? Bên em có chỗ lúc 6pm, 7pm, và 8:30pm.",
        sender: "ai",
        delay: 4000,
      },
      { text: "7pm nhé em!", sender: "customer", delay: 5500 },
      {
        text: "Dạ em đã đặt bàn cho 4 người lúc 7pm tối nay. Chị sẽ nhận tin nhắn xác nhận ngay. Cảm ơn chị!",
        sender: "ai",
        delay: 6500,
      },
    ],
  },
  {
    title: "Cắt Tóc & Tư Vấn Kiểu Tóc",
    messages: [
      {
        text: "Anh muốn cắt tóc fade và tỉa râu. Hôm nay có chỗ không?",
        sender: "customer",
        delay: 0,
      },
      {
        text: "Dạ có ạ! Dịch vụ fade haircut và beard trim là $35. Anh có thể đến lúc 3pm hoặc 5pm hôm nay.",
        sender: "ai",
        delay: 1000,
      },
      { text: "5pm được. Anh có thể xem ảnh mẫu kiểu fade không?", sender: "customer", delay: 2500 },
      {
        text: "Dạ vâng! Em sẽ gửi link album ảnh các kiểu fade phổ biến cho anh. Anh muốn fade thấp, trung bình hay cao ạ?",
        sender: "ai",
        delay: 3500,
      },
      {
        text: "Mid fade nhé em!",
        sender: "customer",
        delay: 5000,
      },
      {
        text: "Dạ perfect! Em đã book lịch mid fade + beard trim lúc 5pm hôm nay. Anh sẽ nhận tin nhắn xác nhận. Hẹn gặp anh!",
        sender: "ai",
        delay: 6000,
      },
    ],
  },
]

export function AITeamSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const [isVisible, setIsVisible] = useState(false)
  const [currentConversation, setCurrentConversation] = useState(0)
  const [displayedMessages, setDisplayedMessages] = useState<any[]>([])
  const [isTyping, setIsTyping] = useState(false)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)
  const chatContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      {
        threshold: 0.1,
        rootMargin: "0px 0px -100px 0px",
      },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current)
      }
    }
  }, [])

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight
    }
  }, [displayedMessages, isTyping])

  useEffect(() => {
    const conversation = conversations[currentConversation]
    setDisplayedMessages([])
    setIsTyping(false)

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }

    let messageIndex = 0

    const showNextMessage = () => {
      if (messageIndex >= conversation.messages.length) {
        timeoutRef.current = setTimeout(() => {
          setCurrentConversation((prev) => (prev + 1) % conversations.length)
        }, 3000)
        return
      }

      const message = conversation.messages[messageIndex]

      timeoutRef.current = setTimeout(() => {
        if (message.sender === "ai") {
          setIsTyping(true)
          timeoutRef.current = setTimeout(() => {
            setDisplayedMessages((prev) => [...prev, message])
            setIsTyping(false)
            messageIndex++
            showNextMessage()
          }, 800)
        } else {
          setDisplayedMessages((prev) => [...prev, message])
          messageIndex++
          showNextMessage()
        }
      }, message.delay)
    }

    showNextMessage()

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [currentConversation])

  return (
    <section id="ai-team" ref={sectionRef} className="relative z-10">
      <div className="bg-white rounded-b-[3rem] pt-16 sm:pt-24 pb-16 sm:pb-24 px-4 relative overflow-hidden">
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <div
              className={`inline-flex items-center gap-2 bg-slate-50 border border-slate-200 text-slate-700 px-4 py-2 rounded-full text-sm font-medium mb-6 transition-all duration-1000 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              <MessageCircle className="w-4 h-4" />
              Demo Trợ Lý AI Thông Minh
            </div>

            <h2
              className={`text-4xl md:text-5xl font-bold text-slate-900 mb-4 transition-all duration-1000 delay-200 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              Xem AI Xử Lý{" "}
              <span className="bg-gradient-to-r from-slate-600 to-slate-400 bg-clip-text text-transparent">
                Khách Hàng Thật
              </span>
            </h2>

            <p
              className={`text-xl text-slate-600 max-w-2xl mx-auto transition-all duration-1000 delay-400 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              Xem AI của chúng tôi trả lời câu hỏi, đặt lịch hẹn và hỗ trợ khách hàng 24/7.
            </p>
          </div>

          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20 max-w-7xl mx-auto">
            {/* Left side - Text content */}
            <div className="w-full lg:w-1/2 flex flex-col justify-center lg:h-[600px] space-y-6 lg:space-y-8 order-2 lg:order-1">
              <div
                className={`transition-all duration-1000 delay-600 ${
                  isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"
                }`}
              >
                <h3 className="text-2xl lg:text-3xl font-bold text-slate-900 mb-4 lg:mb-6">
                  Đây là những gì khách hàng của bạn thấy
                </h3>

                <div className="space-y-3 lg:space-y-4 text-base lg:text-lg text-slate-700 leading-relaxed">
                  <p>
                    Khi tiệm đóng cửa, trợ lý AI vẫn đang trả lời câu hỏi, đặt lịch hẹn và phục vụ khách hàng 24/7.
                  </p>

                  <p>
                    Mỗi cuộc trò chuyện bạn đang xem có thể đang diễn ra lúc nửa đêm, vào Chủ Nhật, hoặc khi bạn đang bận với khách hàng khác.
                  </p>

                  <p className="text-lg lg:text-xl font-semibold text-slate-900">
                    Đối thủ của bạn đang mất những khách hàng này.
                  </p>
                </div>
              </div>

              <div
                className={`transition-all duration-1000 delay-800 ${
                  isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"
                }`}
              >
                <div className="p-4 lg:p-6 bg-slate-50 rounded-xl border-l-4 border-slate-900">
                  <p className="text-slate-800 font-medium text-sm lg:text-base">
                    "Từ chỗ bỏ lỡ 70% tin nhắn ngoài giờ, giờ tôi không bỏ lỡ một khách hàng nào. Lượng đặt lịch tăng 50% chỉ trong tháng đầu tiên."
                  </p>
                  <p className="text-xs lg:text-sm text-slate-600 mt-2">— Chị Lan Nguyen, Chủ Tiệm Nail Boston</p>
                </div>
              </div>
            </div>

            {/* Right side - Phone mockup */}
            <div className="w-full lg:w-1/2 flex justify-center order-1 lg:order-2">
              <div className="max-w-md w-full">
                <div
                  className={`relative transition-all duration-1000 delay-600 ${
                    isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                  }`}
                >
                  <div className="bg-slate-900 rounded-[2.5rem] p-2 shadow-2xl">
                    <div className="bg-black rounded-[2rem] p-1">
                      <div className="bg-white rounded-[1.5rem] overflow-hidden">
                        <div className="bg-slate-50 px-6 py-3 flex justify-between items-center text-sm">
                          <div className="flex items-center gap-1">
                            <div className="w-2 h-2 bg-slate-900 rounded-full"></div>
                            <span className="font-medium text-slate-700">Trợ Lý AI Thile</span>
                          </div>
                          <div className="flex items-center gap-1 text-slate-500">
                            <Clock className="w-3 h-3" />
                            <span className="text-xs">24/7</span>
                          </div>
                        </div>

                        <div className="bg-slate-900 px-6 py-4 text-white">
                          <div className="flex items-center gap-3">
                            <img
                              src="/images/michael-ai-agent.jpg"
                              alt="Minh - Trợ Lý AI"
                              className="w-8 h-8 rounded-full object-cover mr-2 mt-1 flex-shrink-0"
                            />
                            <div className="flex-1">
                              <h3 className="font-semibold text-sm">Minh - Trợ Lý AI</h3>
                              <p className="text-xs text-slate-300">Chat với 617-234-5678</p>
                            </div>
                            <div className="text-xs text-green-400 flex items-center gap-1">
                              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                              Online
                            </div>
                          </div>
                        </div>

                        {/* Chat messages */}
                        <div
                          ref={chatContainerRef}
                          className="h-96 overflow-y-scroll scrollbar-hide p-4 space-y-3 bg-slate-50"
                          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
                        >
                          {displayedMessages.map((message, index) => (
                            <div
                              key={index}
                              className={`flex ${message.sender === "customer" ? "justify-end" : "justify-start"}`}
                            >
                              {message.sender === "ai" && (
                                <img
                                  src="/images/michael-ai-agent.jpg"
                                  alt="Minh"
                                  className="w-6 h-6 rounded-full object-cover mr-2 mt-1 flex-shrink-0"
                                />
                              )}
                              <div
                                className={`max-w-[80%] p-3 rounded-2xl text-sm leading-relaxed ${
                                  message.sender === "customer"
                                    ? "bg-slate-900 text-white rounded-br-md"
                                    : "bg-white text-slate-800 shadow-sm border border-slate-200 rounded-bl-md"
                                }`}
                              >
                                {message.text.split("\n").map((line, i) => (
                                  <div key={i}>{line}</div>
                                ))}
                              </div>
                              {message.sender === "customer" && (
                                <div className="w-6 h-6 rounded-full bg-slate-400 ml-2 mt-1 flex-shrink-0 flex items-center justify-center text-xs text-white font-medium">
                                  K
                                </div>
                              )}
                            </div>
                          ))}

                          {/* Typing indicator */}
                          {isTyping && (
                            <div className="flex justify-start items-start">
                              <img
                                src="/images/michael-ai-agent.jpg"
                                alt="Minh"
                                className="w-6 h-6 rounded-full object-cover mr-2 mt-1 flex-shrink-0"
                              />
                              <div className="bg-white p-3 rounded-2xl rounded-bl-md shadow-sm border border-slate-200">
                                <div className="flex space-x-1">
                                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                                  <div
                                    className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                                    style={{ animationDelay: "0.1s" }}
                                  ></div>
                                  <div
                                    className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"
                                    style={{ animationDelay: "0.2s" }}
                                  ></div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="p-4 bg-white border-t border-slate-200">
                          <div className="flex items-center gap-3 bg-slate-100 rounded-full px-4 py-2">
                            <span className="text-slate-500 text-sm lg:text-base flex-1">Minh đang trả lời...</span>
                            <div className="w-6 h-6 bg-slate-900 rounded-full flex items-center justify-center">
                              <Zap className="w-3 h-3 text-white" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
