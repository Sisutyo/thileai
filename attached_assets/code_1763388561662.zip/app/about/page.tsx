import { GlassmorphismNav } from "@/components/glassmorphism-nav"
import { Footer } from "@/components/footer"
import Aurora from "@/components/Aurora"

export const metadata = {
  title: "Về Chúng Tôi - Thile AI Automation",
  description: "Tìm hiểu về Thile AI Automation - giải pháp tự động hóa AI cho doanh nghiệp truyền thống Việt tại Mỹ.",
}

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-black overflow-hidden">
      <main className="min-h-screen relative overflow-hidden">
        <div className="fixed inset-0 w-full h-full">
          <Aurora colorStops={["#475569", "#64748b", "#475569"]} amplitude={1.2} blend={0.6} speed={0.8} />
        </div>
        <div className="relative z-10">
          <GlassmorphismNav />
          
          <div className="max-w-4xl mx-auto px-6 py-20">
            <div className="animate-fade-in-hero opacity-0">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Về Chúng Tôi</h1>
              <p className="text-white/80 text-lg mb-8">
                Thile AI Automation được thành lập để giúp các doanh nghiệp truyền thống Việt Nam tại Mỹ phát triển bằng công nghệ AI hiện đại.
              </p>
            </div>

            <div className="space-y-12 mt-12">
              <section className="animate-fade-in-section opacity-0">
                <h2 className="text-3xl font-bold text-white mb-4">Sứ Mệnh Của Chúng Tôi</h2>
                <p className="text-white/70 text-lg leading-relaxed">
                  Chúng tôi tin rằng mọi doanh nghiệp, bất kể quy mô hay ngành nghề, đều xứng đáng được hưởng lợi từ công nghệ AI. 
                  Sứ mệnh của Thile AI Automation là cung cấp các giải pháp tự động hóa thông minh, dễ sử dụng và chi phí hợp lý 
                  cho các tiệm Nail, salon tóc, nhà hàng, cửa hàng sửa xe và các doanh nghiệp truyền thống khác.
                </p>
              </section>

              <section className="animate-fade-in-section opacity-0" style={{ animationDelay: "0.2s" }}>
                <h2 className="text-3xl font-bold text-white mb-4">Tầm Nhìn</h2>
                <p className="text-white/70 text-lg leading-relaxed">
                  Chúng tôi hướng tới một tương lai nơi mà các doanh nhân Việt tại Mỹ có thể tập trung vào điều họ yêu thích - 
                  phục vụ khách hàng và phát triển kinh doanh - trong khi AI xử lý các tác vụ lặp lại như trả lời cuộc gọi, 
                  tin nhắn, và quản lý lịch hẹn. Chúng tôi muốn giúp bạn không bao giờ bỏ lỡ một khách hàng.
                </p>
              </section>

              <section className="animate-fade-in-section opacity-0" style={{ animationDelay: "0.4s" }}>
                <h2 className="text-3xl font-bold text-white mb-4">Giá Trị Cốt Lõi</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/10">
                    <h3 className="text-xl font-bold text-white mb-3">Đơn Giản</h3>
                    <p className="text-white/70">
                      Công nghệ AI không cần phức tạp. Chúng tôi tạo ra các giải pháp dễ hiểu và dễ sử dụng.
                    </p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/10">
                    <h3 className="text-xl font-bold text-white mb-3">Hiệu Quả</h3>
                    <p className="text-white/70">
                      Giúp bạn tiết kiệm thời gian và chi phí bằng cách tự động hóa các tác vụ thường ngày.
                    </p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/10">
                    <h3 className="text-xl font-bold text-white mb-3">Tin Cậy</h3>
                    <p className="text-white/70">
                      AI của chúng tôi hoạt động 24/7, không bao giờ mệt mỏi, không bao giờ bỏ lỡ khách hàng.
                    </p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/10">
                    <h3 className="text-xl font-bold text-white mb-3">Hỗ Trợ</h3>
                    <p className="text-white/70">
                      Đội ngũ chúng tôi luôn sẵn sàng giúp bạn thành công với dịch vụ hỗ trợ kỹ thuật tuyệt vời.
                    </p>
                  </div>
                </div>
              </section>

              <section className="animate-fade-in-section opacity-0" style={{ animationDelay: "0.6s" }}>
                <h2 className="text-3xl font-bold text-white mb-4">Tại Sao Chọn Thile AI?</h2>
                <ul className="space-y-4 text-white/70">
                  <li className="flex items-start">
                    <span className="text-red-500 mr-4 font-bold">✓</span>
                    <span>Được thiết kế đặc biệt cho doanh nghiệp truyền thống Việt Nam</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-4 font-bold">✓</span>
                    <span>Hỗ trợ tiếng Việt hoàn toàn</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-4 font-bold">✓</span>
                    <span>Chi phí hợp lý, không cần đầu tư lớn</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-4 font-bold">✓</span>
                    <span>Triển khai nhanh chóng, có thể bắt đầu trong vài giờ</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-4 font-bold">✓</span>
                    <span>Không cần kiến thức kỹ thuật để sử dụng</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-red-500 mr-4 font-bold">✓</span>
                    <span>Luôn cập nhật và cải thiện dựa trên phản hồi của khách hàng</span>
                  </li>
                </ul>
              </section>
            </div>
          </div>

          <Footer />
        </div>
      </main>
    </div>
  )
}
