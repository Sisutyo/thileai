import { GlassmorphismNav } from "@/components/glassmorphism-nav"
import { Footer } from "@/components/footer"
import Aurora from "@/components/Aurora"

export const metadata = {
  title: "Chính Sách Bảo Mật - Thile AI Automation",
  description: "Chính sách bảo mật của Thile AI Automation",
}

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-black overflow-hidden">
      <main className="min-h-screen relative overflow-hidden">
        <div className="fixed inset-0 w-full h-full">
          <Aurora colorStops={["#475569", "#64748b", "#475569"]} amplitude={1.2} blend={0.6} speed={0.8} />
        </div>
        <div className="relative z-10">
          <GlassmorphismNav />
          
          <div className="max-w-4xl mx-auto px-6 py-20">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-8">Chính Sách Bảo Mật</h1>
            <p className="text-white/70 text-sm mb-12">Cập nhật lần cuối: {new Date().toLocaleDateString('vi-VN')}</p>

            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-bold text-white mb-4">1. Giới Thiệu</h2>
                <p className="text-white/70 leading-relaxed">
                  Thile AI Automation ("Công ty," "chúng tôi," hoặc "của chúng tôi") cam kết bảo vệ quyền riêng tư của bạn. 
                  Chính sách bảo mật này giải thích cách chúng tôi thu thập, sử dụng, tiết lộ và bảo vệ thông tin của bạn.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">2. Thông Tin Chúng Tôi Thu Thập</h2>
                <p className="text-white/70 mb-4">Chúng tôi có thể thu thập các loại thông tin sau:</p>
                <ul className="space-y-2 text-white/70 ml-4">
                  <li>• Thông tin cá nhân (tên, email, số điện thoại, địa chỉ)</li>
                  <li>• Thông tin kinh doanh (tên công ty, loại ngành)</li>
                  <li>• Thông tin sử dụng (dữ liệu khách hàng, lịch hẹn, tin nhắn)</li>
                  <li>• Thông tin kỹ thuật (địa chỉ IP, loại trình duyệt, hệ điều hành)</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">3. Cách Chúng Tôi Sử Dụng Thông Tin</h2>
                <p className="text-white/70 mb-4">Chúng tôi sử dụng thông tin của bạn để:</p>
                <ul className="space-y-2 text-white/70 ml-4">
                  <li>• Cung cấp và cải thiện dịch vụ của chúng tôi</li>
                  <li>• Hỗ trợ khách hàng và xử lý yêu cầu</li>
                  <li>• Gửi thông báo và cập nhật</li>
                  <li>• Tuân thủ các yêu cầu pháp lý</li>
                  <li>• Phòng chống gian lận và bảo vệ bảo mật</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">4. Chia Sẻ Thông Tin</h2>
                <p className="text-white/70 leading-relaxed">
                  Chúng tôi không bán hoặc chia sẻ thông tin cá nhân của bạn với bên thứ ba, ngoại trừ khi cần thiết để:
                  <ul className="space-y-2 text-white/70 ml-4 mt-4">
                    <li>• Cung cấp dịch vụ (ví dụ: nhà cung cấp dịch vụ đám mây)</li>
                    <li>• Tuân thủ pháp luật hoặc lệnh của tòa án</li>
                    <li>• Bảo vệ quyền và an toàn của chúng tôi</li>
                  </ul>
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">5. Bảo Mật Dữ Liệu</h2>
                <p className="text-white/70 leading-relaxed">
                  Chúng tôi sử dụng các biện pháp bảo mật kỹ thuật và quản trị thích hợp để bảo vệ thông tin của bạn 
                  khỏi truy cập trái phép, thay đổi, tiết lộ hoặc phá hủy. Tuy nhiên, không có phương pháp truyền tải 
                  hoặc lưu trữ điện tử nào hoàn toàn an toàn.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">6. Quyền Của Bạn</h2>
                <p className="text-white/70 mb-4">Bạn có quyền:</p>
                <ul className="space-y-2 text-white/70 ml-4">
                  <li>• Truy cập thông tin cá nhân của bạn</li>
                  <li>• Yêu cầu chỉnh sửa hoặc xóa thông tin</li>
                  <li>• Từ chối nhận các liên lạc tiếp thị</li>
                  <li>• Rút lại sự đồng ý của bạn bất kỳ lúc nào</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">7. Thay Đổi Chính Sách Này</h2>
                <p className="text-white/70 leading-relaxed">
                  Chúng tôi có thể cập nhật chính sách bảo mật này theo thời gian. Chúng tôi sẽ thông báo cho bạn 
                  về bất kỳ thay đổi nào bằng cách đăng chính sách mới trên trang web này.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">8. Liên Hệ Chúng Tôi</h2>
                <p className="text-white/70">
                  Nếu bạn có bất kỳ câu hỏi nào về chính sách bảo mật này, vui lòng liên hệ với chúng tôi tại:
                </p>
                <div className="mt-4 text-white/70">
                  <p>Email: <a href="mailto:privacy@thileai.com" className="text-red-500 hover:text-red-400">privacy@thileai.com</a></p>
                  <p>Điện Thoại: <a href="tel:+16179999999" className="text-red-500 hover:text-red-400">+1 (617) 999-9999</a></p>
                </div>
              </section>
            </div>
          </div>

          <Footer />
        </div>
      </main>
    </div>
  )
}
