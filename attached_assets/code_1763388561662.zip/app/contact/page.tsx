import { GlassmorphismNav } from "@/components/glassmorphism-nav"
import { Footer } from "@/components/footer"
import Aurora from "@/components/Aurora"

export const metadata = {
  title: "Liên Hệ - Thile AI Automation",
  description: "Liên hệ với Thile AI Automation để tìm hiểu thêm về giải pháp tự động hóa AI cho doanh nghiệp của bạn.",
}

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-black overflow-hidden">
      <main className="min-h-screen relative overflow-hidden">
        <div className="fixed inset-0 w-full h-full">
          <Aurora colorStops={["#475569", "#64748b", "#475569"]} amplitude={1.2} blend={0.6} speed={0.8} />
        </div>
        <div className="relative z-10">
          <GlassmorphismNav />
          
          <div className="max-w-4xl mx-auto px-6 py-20">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Liên Hệ Chúng Tôi</h1>
              <p className="text-white/80 text-lg">
                Hãy liên hệ với chúng tôi để tìm hiểu cách Thile AI có thể giúp doanh nghiệp của bạn phát triển.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              {/* Contact Info */}
              <div className="space-y-8">
                <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/10">
                  <h3 className="text-white font-bold text-lg mb-3">Điện Thoại</h3>
                  <p className="text-white/70">
                    <a href="tel:+16179999999" className="hover:text-white transition-colors">
                      +1 (617) 999-9999
                    </a>
                  </p>
                  <p className="text-white/50 text-sm mt-2">Thứ Hai - Thứ Sáu: 9AM - 6PM EST</p>
                </div>

                <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/10">
                  <h3 className="text-white font-bold text-lg mb-3">Email</h3>
                  <p className="text-white/70">
                    <a href="mailto:hello@thileai.com" className="hover:text-white transition-colors">
                      hello@thileai.com
                    </a>
                  </p>
                  <p className="text-white/50 text-sm mt-2">Chúng tôi sẽ phản hồi trong 24 giờ</p>
                </div>

                <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/10">
                  <h3 className="text-white font-bold text-lg mb-3">Địa Chỉ</h3>
                  <p className="text-white/70">
                    Boston, Massachusetts<br/>
                    United States of America
                  </p>
                </div>

                <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/10">
                  <h3 className="text-white font-bold text-lg mb-3">Mạng Xã Hội</h3>
                  <div className="flex space-x-4">
                    <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-white transition-colors">
                      Facebook
                    </a>
                    <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-white transition-colors">
                      Instagram
                    </a>
                    <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-white transition-colors">
                      YouTube
                    </a>
                  </div>
                </div>
              </div>

              {/* Contact Form */}
              <div className="bg-white/10 backdrop-blur-md rounded-lg p-8 border border-white/10">
                <h3 className="text-white font-bold text-xl mb-6">Gửi Thông Điệp</h3>
                <form className="space-y-4">
                  <div>
                    <label className="block text-white/70 text-sm mb-2">Tên</label>
                    <input 
                      type="text" 
                      placeholder="Nhập tên của bạn"
                      className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:border-white/40 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-white/70 text-sm mb-2">Email</label>
                    <input 
                      type="email" 
                      placeholder="hello@example.com"
                      className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:border-white/40 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-white/70 text-sm mb-2">Điện Thoại</label>
                    <input 
                      type="tel" 
                      placeholder="+1 (617) 123-4567"
                      className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:border-white/40 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-white/70 text-sm mb-2">Loại Doanh Nghiệp</label>
                    <select className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-white/40 transition-colors">
                      <option value="">Chọn loại doanh nghiệp</option>
                      <option value="nail">Tiệm Nail</option>
                      <option value="salon">Salon Tóc</option>
                      <option value="restaurant">Nhà Hàng</option>
                      <option value="auto">Cửa Hàng Sửa Xe</option>
                      <option value="other">Khác</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-white/70 text-sm mb-2">Tin Nhắn</label>
                    <textarea 
                      placeholder="Nhập tin nhắn của bạn..."
                      rows={4}
                      className="w-full bg-white/5 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:border-white/40 transition-colors resize-none"
                    />
                  </div>
                  <button 
                    type="submit"
                    className="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-2 rounded-lg transition-colors"
                  >
                    Gửi Thông Điệp
                  </button>
                </form>
              </div>
            </div>
          </div>

          <Footer />
        </div>
      </main>
    </div>
  )
}
