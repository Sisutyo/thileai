import { GlassmorphismNav } from "@/components/glassmorphism-nav"
import { Footer } from "@/components/footer"
import Aurora from "@/components/Aurora"

export const metadata = {
  title: "Điều Khoản Dịch Vụ - Thile AI Automation",
  description: "Điều khoản dịch vụ của Thile AI Automation",
}

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-black overflow-hidden">
      <main className="min-h-screen relative overflow-hidden">
        <div className="fixed inset-0 w-full h-full">
          <Aurora colorStops={["#475569", "#64748b", "#475569"]} amplitude={1.2} blend={0.6} speed={0.8} />
        </div>
        <div className="relative z-10">
          <GlassmorphismNav />
          
          <div className="max-w-4xl mx-auto px-6 py-20">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-8">Điều Khoản Dịch Vụ</h1>
            <p className="text-white/70 text-sm mb-12">Cập nhật lần cuối: {new Date().toLocaleDateString('vi-VN')}</p>

            <div className="space-y-8">
              <section>
                <h2 className="text-2xl font-bold text-white mb-4">1. Chấp Nhận Điều Khoản</h2>
                <p className="text-white/70 leading-relaxed">
                  Bằng cách truy cập và sử dụng các dịch vụ của Thile AI Automation, bạn đồng ý bị ràng buộc bởi 
                  các điều khoản và điều kiện này. Nếu bạn không đồng ý với bất kỳ phần nào, vui lòng không sử dụng dịch vụ của chúng tôi.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">2. Mô Tả Dịch Vụ</h2>
                <p className="text-white/70 leading-relaxed">
                  Thile AI Automation cung cấp các giải pháp tự động hóa AI, bao gồm nhưng không giới hạn ở:
                  <ul className="space-y-2 text-white/70 ml-4 mt-4">
                    <li>• Chatbot AI xử lý tin nhắn và cuộc gọi</li>
                    <li>• Quản lý lịch hẹn tự động</li>
                    <li>• Phân tích dữ liệu khách hàng</li>
                    <li>• Tích hợp với các hệ thống hiện tại của bạn</li>
                  </ul>
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">3. Tài Khoản Người Dùng</h2>
                <p className="text-white/70 leading-relaxed">
                  Bạn chịu trách nhiệm duy trì tính bảo mật của tài khoản của bạn và mật khẩu. 
                  Bạn đồng ý chịu trách nhiệm cho tất cả các hoạt động xảy ra dưới tài khoản của bạn. 
                  Bạn phải thông báo cho chúng tôi ngay lập tức về bất kỳ truy cập trái phép nào.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">4. Hành Vi Được Phép</h2>
                <p className="text-white/70 mb-4">Bạn đồng ý không sử dụng dịch vụ để:</p>
                <ul className="space-y-2 text-white/70 ml-4">
                  <li>• Vi phạm bất kỳ luật pháp hoặc quy định nào</li>
                  <li>• Xâm phạm quyền của người khác</li>
                  <li>• Gửi nội dung lạm dụng, qu骚扰 hoặc lừa đảo</li>
                  <li>• Thực hiện các hoạt động độc hại hoặc gây mất ổn định</li>
                  <li>• Truy cập trái phép vào các phần của dịch vụ</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">5. Quyền Sở Hữu Trí Tuệ</h2>
                <p className="text-white/70 leading-relaxed">
                  Tất cả nội dung, tính năng và chức năng (bao gồm nhưng không giới hạn ở thiết kế, văn bản, đồ họa, 
                  logo, hình ảnh, âm thanh và phần mềm) thuộc sở hữu của Thile AI Automation hoặc các nhà cung cấp cấp phép của chúng tôi.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">6. Tuyên Bố Từ Chối Trách Nhiệm</h2>
                <p className="text-white/70 leading-relaxed">
                  DỰA VÀO HIỆN TRẠNG, THILE AI AUTOMATION CUNG CẤP DỊCH VỤ "NHƯ CÓ" VÀ "NHƯ CÓ SẴN" 
                  MÀ KHÔNG CÓ BẢO ĐẢM BẤT KỲ LOẠI NÀO, RÕ RÀNG HOẶC NGỤ Ý. 
                  CHÚNG TÔI KHÔNG ĐẢM BẢO RẰNG DỊCH VỤ SẼ KHÔNG BỊ GIÁN ĐOẠN HOẶC KHÔNG CÓ LỖI.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">7. Giới Hạn Trách Nhiệm</h2>
                <p className="text-white/70 leading-relaxed">
                  TRONG PHẠM VI TỐI ĐA DO LUẬT PHÁP CHO PHÉP, THILE AI AUTOMATION SẼ KHÔNG CHỊU TRÁCH NHIỆM 
                  VỀ BẤT KỲ THIỆT HẠI GIÁN TIẾP, KHÔNG CÓ DỤNG ÝTRỰC TIẾP, ĐẶC BIỆT, NGẪU NHIÊN HOẶC HẬU QUẢ NÀO.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">8. Thanh Toán và Hóa Đơn</h2>
                <p className="text-white/70 leading-relaxed">
                  Bạn đồng ý thanh toán tất cả các khoản phí theo các giá được liệt kê. 
                  Các khoản phí được tính theo tháng trừ khi khác trong hợp đồng dịch vụ của bạn. 
                  Thanh toán phải được thực hiện kịp thời.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">9. Hủy Bỏ</h2>
                <p className="text-white/70 leading-relaxed">
                  Bạn có thể hủy bỏ dịch vụ bất kỳ lúc nào bằng cách liên hệ với chúng tôi. 
                  Hủy bỏ sẽ có hiệu lực vào cuối kỳ hóa đơn hiện tại. Không có hoàn tiền cho các khoản phí đã trả.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">10. Thay Đổi Điều Khoản</h2>
                <p className="text-white/70 leading-relaxed">
                  Chúng tôi có quyền thay đổi các điều khoản này bất kỳ lúc nào. 
                  Chúng tôi sẽ thông báo cho bạn về các thay đổi quan trọng bằng email hoặc thông báo trên trang web.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-white mb-4">11. Liên Hệ</h2>
                <p className="text-white/70">
                  Nếu bạn có bất kỳ câu hỏi nào về các điều khoản này, vui lòng liên hệ với chúng tôi tại:
                </p>
                <div className="mt-4 text-white/70">
                  <p>Email: <a href="mailto:legal@thileai.com" className="text-red-500 hover:text-red-400">legal@thileai.com</a></p>
                  <p>Điện Thoại: <a href="tel:+16179999999" className="text-red-500 hover:text-red-400">+1 (617) 999-9999</a></p>
                </div>
              </section>
            </div>
          </div>

          <Footer />
        </div>
      </main>
    </div>
  )
}
